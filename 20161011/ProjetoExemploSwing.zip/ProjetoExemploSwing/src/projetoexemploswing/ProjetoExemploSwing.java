
package projetoexemploswing;

import java.util.ArrayList;
import projetoexemploswing.DAO.LivroDao;
import projetoexemploswing.Dominio.Autor;
import projetoexemploswing.Dominio.Livro;


public class ProjetoExemploSwing {

    public static void main(String[] args) {
     
           
        Livro livro1 = new Livro("Java", "1223qwe", new Autor("Juquinha","123"));
        Livro livro2 = new Livro("C#", "qwq1212", new Autor("Bolinha","999"));
        Livro livro3 = new Livro("TypeScript", "AABB44", new Autor("Juquinha","123"));
        Livro livro4 = new Livro("JavaScript", "CFFF66", new Autor("Bolinha","999"));
                        
        LivroDao ld = new LivroDao();
        
        ld.inserir(livro1);
        ld.inserir(livro2);
        ld.inserir(livro3);
        ld.inserir(livro4);
        
        ArrayList<Livro> livros =  ld.buscarTodos();
        
        for (Livro livro : livros) {
            System.err.println("Livro: "+ livro.getTitulo());
        }
        
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoexemploswing;

import java.util.ArrayList;
import projetoexemploswing.Dominio.Autor;
import projetoexemploswing.Dominio.Livro;

public class Banco {
    
    public static ArrayList<Livro> BANCOLIVROS = new ArrayList<Livro>();
    public static ArrayList<Autor> BANCOAUTOR = new ArrayList<Autor>();

    public static ArrayList<Livro> getBANCOLIVROS() {
        return BANCOLIVROS;
    }

    public static ArrayList<Autor> getBANCOAUTOR() {
        return BANCOAUTOR;
    }
   
    
}

package br.imd;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class LeilaoTest {

	@Test
	public void deveReceberUmLance() {
		Leilao leilao = new Leilao("Notebook");
		assertEquals(0, leilao.getLances().size());
		leilao.propoe(new Lance(new Usuario("JOsé"), 2000));
		assertEquals(1, leilao.getLances().size());
		assertEquals(2000, leilao.getLances().get(0).getValor(), 0);
	}

	@Test
	public void deveReceberVariosLances() {
		Leilao leilao = new Leilao("Notebook");
		leilao.propoe(new Lance(new Usuario("Josẽ"), 2000));
		leilao.propoe(new Lance(new Usuario("Maria"), 3000));
		assertEquals(2, leilao.getLances().size());
		assertEquals(2000.0, leilao.getLances().get(0).getValor(), 0);
		assertEquals(3000.0, leilao.getLances().get(1).getValor(), 0);
	}

	@Test
	public void naoDeveAceitarDoisLancesSeguidosDoMesmoUsuario() {
		Leilao leilao = new Leilao("Notebook");
		Usuario jose = new Usuario("jose");

		leilao.propoe(new Lance(jose, 2000));
		leilao.propoe(new Lance(jose, 3000));

		assertEquals(1, leilao.getLances().size());
		assertEquals(2000.0, leilao.getLances().get(0).getValor(), 0);

	}

	@Test
	public void naoDeveAceitarMaisDoQueCincoLancesDoMesmoUsuario() {
		Leilao leilao = new Leilao("notebook");
		Usuario jose = new Usuario("jose");
		Usuario maria = new Usuario("maria");
		
		leilao.propoe(new Lance(jose, 2000));
		leilao.propoe(new Lance(maria, 3000));
		
		leilao.propoe(new Lance(jose, 4000));
		leilao.propoe(new Lance(maria, 5000));
		
		leilao.propoe(new Lance(jose, 6000));
		leilao.propoe(new Lance(maria, 7000));
		
		leilao.propoe(new Lance(jose, 8000));
		leilao.propoe(new Lance(maria, 9000));
		
		leilao.propoe(new Lance(jose, 10000));
		leilao.propoe(new Lance(maria, 11000));
		//Lance ignorado
		leilao.propoe(new Lance(jose, 12000));
		
		assertEquals(10, leilao.getLances().size());
		assertEquals(11000, 
		leilao.getLances().get(leilao.getLances().size()-1).getValor(), 0);
	
	}

}

















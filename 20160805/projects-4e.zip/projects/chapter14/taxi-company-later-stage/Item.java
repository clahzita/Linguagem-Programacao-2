/**
 * An item in the city.
 * 
 * @author David J. Barnes and Michael Kolling
 * @version 2008.03.30
 */

public interface Item
{
    public Location getLocation();
}

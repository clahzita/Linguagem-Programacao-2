/**
 * The test class TaxiTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class TaxiTest extends junit.framework.TestCase
{
    private Taxi taxi;
    
    /**
     * Default constructor for test class TaxiTest
     */
    public TaxiTest()
    {
    }

    /**
     * Create a taxi.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
        TaxiCompany company = new TaxiCompany();
        Location taxiLocation = new Location();
        taxi = new Taxi(company, taxiLocation);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }
    
    /**
     * Test creation and the initial state of a taxi.
     */
    public void testCreation()
    {
        assertEquals(true, taxi.isFree());
    }
    
    /**
     * Test that a taxi is no longer free after it has
     * picked up a passenger.
     */
    public void testPickup()
    {
        Location pickup = new Location();
        Location destination = new Location();
        Passenger passenger = new Passenger(pickup, destination);
        taxi.pickup(passenger);
        assertEquals(false, taxi.isFree());
    }
    
    /**
     * Test that a taxi becomes free again after offloading
     * a passenger.
     */
    public void testOffload()
    {
        testPickup();
        taxi.offloadPassenger();
        assertEquals(true, taxi.isFree());
    }
}


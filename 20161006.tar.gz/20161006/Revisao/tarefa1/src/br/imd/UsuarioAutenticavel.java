package br.imd;

abstract class UsuarioAutenticavel {
	private String nome;
	private int senha;
	
	public boolean autentica(int senha){
		
	}
	
}

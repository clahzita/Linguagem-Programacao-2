package br.imd;

public class Cliente extends UsuarioAutenticavel{
	
	
	public Cliente(String nome, String senha) {
		super();
		this.nome = nome;
		this.senha = senha;
	}
	
	
}

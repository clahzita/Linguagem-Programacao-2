package br.imd.funcionario;

public class AuxiliarAdministrativo extends Funcionario {

	public AuxiliarAdministrativo(String matricula, String nome, String CPF) {
		super(matricula, nome, CPF);
		// TODO Auto-generated constructor stub
	}

}

package br.imd.funcionario;

public class Secretario extends Funcionario {

	public Secretario(String matricula, String nome, String CPF) {
		super(matricula, nome, CPF);
		// TODO Auto-generated constructor stub
	}

}

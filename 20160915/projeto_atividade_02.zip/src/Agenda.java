public class Agenda {

	private Contato contato1;
	private Contato contato2;
	private Contato contato3;

	public Contato getContato1() {
		return contato1;
	}

	public void setContato1(Contato contato1) {
		this.contato1 = contato1;
	}

	public Contato getContato2() {
		return contato2;
	}

	public void setContato2(Contato contato2) {
		this.contato2 = contato2;
	}

	public Contato getContato3() {
		return contato3;
	}

	public void setContato3(Contato contato3) {
		this.contato3 = contato3;
	}

}

package br.ufrn.imd.emerson;

public class Carro extends Veiculo {

	
	private int chassi;
	private boolean quatroPortas;

	public Carro(String marca){
		super(marca);
		//super("Fiat");
	}
	
	
	@Override
	public boolean equals(Object obj) {
	
	if((obj instanceof Carro) && ((Carro)obj).chassi == this.chassi ){		
		return true;
	}else{		
		return false;
	}
			
	}
	@Override
	public String toString() {
		return this.modelo;
	}
	
	public boolean isQuatroPortas() {
		return quatroPortas;
	}

	public void setQuatroPortas(boolean quatroPortas) {
		this.quatroPortas = quatroPortas;
	}
	
		
	
	@Override
	public void imprimirDados() {		
		super.imprimirDados();
		System.out.println("4 portas: "+ this.quatroPortas);
	
	}
	
}

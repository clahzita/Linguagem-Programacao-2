package br.ufrn.imd.emerson;

public class Principal {

	public static void main(String[] args) {
			
		Carro c = new Carro("Fiat");
		
		c.setMarca("Fiat");
		c.setModelo("Uno");
		c.setAno(2015);
		
		c.setQuatroPortas(true);
		
		//c.imprimirDados();
		
		//System.out.println(c);
		
		
		

	}

}
